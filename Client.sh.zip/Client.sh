#!/bin/bash

# Clone the Citra repository
git clone --recursive https://github.com/citra-emu/citra.git
cd citra

# Set the Qt5 directory
export Qt5_DIR=$(brew --prefix)/opt/qt5

# Create the build directory
mkdir build
cd build

# Install dependencies
brew install pkg-config
brew install sdl2
brew install qt5
brew install cmake
brew install openssl

# Build Citra
cmake ..
make -j$(nproc)
